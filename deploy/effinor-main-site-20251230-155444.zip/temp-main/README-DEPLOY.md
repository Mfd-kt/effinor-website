# Instructions de déploiement - Site principal

## 1. Uploader les fichiers
- Extrayez tous les fichiers dans `public_html/` sur Hostinger

## 2. Installer les dépendances
```bash
cd public_html
npm install --production
```

## 3. Créer le fichier .env.local
```bash
cp .env.example .env.local
# Puis éditez .env.local avec vos vraies valeurs
```

## 4. Configurer Node.js dans Hostinger
- Créer une application Node.js
- Point d'entrée: `node_modules/.bin/next start`
- Port: 3000 (ou celui fourni par Hostinger)
- Variables d'environnement: Copier depuis .env.local

## 5. Démarrer l'application
L'application devrait démarrer automatiquement via Hostinger Node.js Manager
